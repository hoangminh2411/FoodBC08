import { Menu } from "../models/Menu.js";

// let arrMonAn = [];

let menu = new Menu;
menu.layStorage();
menu.renderMenu('tbodyFood');



window.xoaMonAn = function (maMon) {
    
    menu.xoaMonAn(maMon);
    menu.renderMenu('tbodyFood');
}